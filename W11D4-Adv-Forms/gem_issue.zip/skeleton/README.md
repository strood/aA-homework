Issue with gemfile when attmpting to complete this assignment.
